package androidx.appcompat.widget;

/* JADX INFO: loaded from: classes.dex */
public interface WithHint {
    CharSequence getHint();
}
