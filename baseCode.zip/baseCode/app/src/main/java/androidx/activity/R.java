package androidx.activity;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class attr {
        public static final int alpha = 0x7f04002e;
        public static final int font = 0x7f04018a;
        public static final int fontProviderAuthority = 0x7f04018c;
        public static final int fontProviderCerts = 0x7f04018d;
        public static final int fontProviderFetchStrategy = 0x7f04018e;
        public static final int fontProviderFetchTimeout = 0x7f04018f;
        public static final int fontProviderPackage = 0x7f040190;
        public static final int fontProviderQuery = 0x7f040191;
        public static final int fontStyle = 0x7f040193;
        public static final int fontVariationSettings = 0x7f040194;
        public static final int fontWeight = 0x7f040195;
        public static final int ttcIndex = 0x7f040400;

        private attr() {
        }
    }

    public static final class color {
        public static final int notification_action_color_filter = 0x7f0600cc;
        public static final int notification_icon_bg_color = 0x7f0600cd;
        public static final int ripple_material_light = 0x7f0600dc;
        public static final int secondary_text_default_material_light = 0x7f0600e6;

        private color() {
        }
    }

    public static final class dimen {
        public static final int compat_button_inset_horizontal_material = 0x7f070057;
        public static final int compat_button_inset_vertical_material = 0x7f070058;
        public static final int compat_button_padding_horizontal_material = 0x7f070059;
        public static final int compat_button_padding_vertical_material = 0x7f07005a;
        public static final int compat_control_corner_material = 0x7f07005b;
        public static final int compat_notification_large_icon_max_height = 0x7f07005c;
        public static final int compat_notification_large_icon_max_width = 0x7f07005d;
        public static final int notification_action_icon_size = 0x7f070192;
        public static final int notification_action_text_size = 0x7f070193;
        public static final int notification_big_circle_margin = 0x7f070194;
        public static final int notification_content_margin_start = 0x7f070195;
        public static final int notification_large_icon_height = 0x7f070196;
        public static final int notification_large_icon_width = 0x7f070197;
        public static final int notification_main_column_padding_top = 0x7f070198;
        public static final int notification_media_narrow_margin = 0x7f070199;
        public static final int notification_right_icon_size = 0x7f07019a;
        public static final int notification_right_side_padding_top = 0x7f07019b;
        public static final int notification_small_icon_background_padding = 0x7f07019c;
        public static final int notification_small_icon_size_as_large = 0x7f07019d;
        public static final int notification_subtext_size = 0x7f07019e;
        public static final int notification_top_pad = 0x7f07019f;
        public static final int notification_top_pad_large_text = 0x7f0701a0;

        private dimen() {
        }
    }

    public static final class drawable {
        public static final int notification_action_background = 0x7f08011e;
        public static final int notification_bg = 0x7f08011f;
        public static final int notification_bg_low = 0x7f080120;
        public static final int notification_bg_low_normal = 0x7f080121;
        public static final int notification_bg_low_pressed = 0x7f080122;
        public static final int notification_bg_normal = 0x7f080123;
        public static final int notification_bg_normal_pressed = 0x7f080124;
        public static final int notification_icon_background = 0x7f080125;
        public static final int notification_template_icon_bg = 0x7f080126;
        public static final int notification_template_icon_low_bg = 0x7f080127;
        public static final int notification_tile_bg = 0x7f080128;
        public static final int notify_panel_notification_icon_bg = 0x7f080129;

        private drawable() {
        }
    }

    public static final class id {
        public static final int accessibility_action_clickable_span = 0x7f0a0024;
        public static final int accessibility_custom_action_0 = 0x7f0a0025;
        public static final int accessibility_custom_action_1 = 0x7f0a0026;
        public static final int accessibility_custom_action_10 = 0x7f0a0027;
        public static final int accessibility_custom_action_11 = 0x7f0a0028;
        public static final int accessibility_custom_action_12 = 0x7f0a0029;
        public static final int accessibility_custom_action_13 = 0x7f0a002a;
        public static final int accessibility_custom_action_14 = 0x7f0a002b;
        public static final int accessibility_custom_action_15 = 0x7f0a002c;
        public static final int accessibility_custom_action_16 = 0x7f0a002d;
        public static final int accessibility_custom_action_17 = 0x7f0a002e;
        public static final int accessibility_custom_action_18 = 0x7f0a002f;
        public static final int accessibility_custom_action_19 = 0x7f0a0030;
        public static final int accessibility_custom_action_2 = 0x7f0a0031;
        public static final int accessibility_custom_action_20 = 0x7f0a0032;
        public static final int accessibility_custom_action_21 = 0x7f0a0033;
        public static final int accessibility_custom_action_22 = 0x7f0a0034;
        public static final int accessibility_custom_action_23 = 0x7f0a0035;
        public static final int accessibility_custom_action_24 = 0x7f0a0036;
        public static final int accessibility_custom_action_25 = 0x7f0a0037;
        public static final int accessibility_custom_action_26 = 0x7f0a0038;
        public static final int accessibility_custom_action_27 = 0x7f0a0039;
        public static final int accessibility_custom_action_28 = 0x7f0a003a;
        public static final int accessibility_custom_action_29 = 0x7f0a003b;
        public static final int accessibility_custom_action_3 = 0x7f0a003c;
        public static final int accessibility_custom_action_30 = 0x7f0a003d;
        public static final int accessibility_custom_action_31 = 0x7f0a003e;
        public static final int accessibility_custom_action_4 = 0x7f0a003f;
        public static final int accessibility_custom_action_5 = 0x7f0a0040;
        public static final int accessibility_custom_action_6 = 0x7f0a0041;
        public static final int accessibility_custom_action_7 = 0x7f0a0042;
        public static final int accessibility_custom_action_8 = 0x7f0a0043;
        public static final int accessibility_custom_action_9 = 0x7f0a0044;
        public static final int action_container = 0x7f0a0051;
        public static final int action_divider = 0x7f0a0053;
        public static final int action_image = 0x7f0a0054;
        public static final int action_text = 0x7f0a005a;
        public static final int actions = 0x7f0a005b;
        public static final int async = 0x7f0a0069;
        public static final int blocking = 0x7f0a009a;
        public static final int chronometer = 0x7f0a00b5;
        public static final int dialog_button = 0x7f0a00d9;
        public static final int forever = 0x7f0a0112;
        public static final int icon = 0x7f0a013d;
        public static final int icon_group = 0x7f0a013e;
        public static final int info = 0x7f0a0183;
        public static final int italic = 0x7f0a0186;
        public static final int line1 = 0x7f0a019a;
        public static final int line3 = 0x7f0a019b;
        public static final int normal = 0x7f0a01f2;
        public static final int notification_background = 0x7f0a01f4;
        public static final int notification_main_column = 0x7f0a01f5;
        public static final int notification_main_column_container = 0x7f0a01f6;
        public static final int right_icon = 0x7f0a022d;
        public static final int right_side = 0x7f0a022e;
        public static final int tag_accessibility_actions = 0x7f0a0299;
        public static final int tag_accessibility_clickable_spans = 0x7f0a029a;
        public static final int tag_accessibility_heading = 0x7f0a029b;
        public static final int tag_accessibility_pane_title = 0x7f0a029c;
        public static final int tag_screen_reader_focusable = 0x7f0a02a0;
        public static final int tag_transition_group = 0x7f0a02a2;
        public static final int tag_unhandled_key_event_manager = 0x7f0a02a3;
        public static final int tag_unhandled_key_listeners = 0x7f0a02a4;
        public static final int text = 0x7f0a02aa;
        public static final int text2 = 0x7f0a02ab;
        public static final int time = 0x7f0a02ba;
        public static final int title = 0x7f0a02bb;
        public static final int view_tree_lifecycle_owner = 0x7f0a038b;
        public static final int view_tree_saved_state_registry_owner = 0x7f0a038c;
        public static final int view_tree_view_model_store_owner = 0x7f0a038d;

        private id() {
        }
    }

    public static final class integer {
        public static final int status_bar_notification_info_maxnum = 0x7f0b001b;

        private integer() {
        }
    }

    public static final class layout {
        public static final int custom_dialog = 0x7f0d0026;
        public static final int notification_action = 0x7f0d007e;
        public static final int notification_action_tombstone = 0x7f0d007f;
        public static final int notification_template_custom_big = 0x7f0d0086;
        public static final int notification_template_icon_group = 0x7f0d0087;
        public static final int notification_template_part_chronometer = 0x7f0d008b;
        public static final int notification_template_part_time = 0x7f0d008c;

        private layout() {
        }
    }

    public static final class string {
        public static final int status_bar_notification_info_overflow = 0x7f110189;

        private string() {
        }
    }

    public static final class style {
        public static final int TextAppearance_Compat_Notification = 0x7f120167;
        public static final int TextAppearance_Compat_Notification_Info = 0x7f120168;
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f12016a;
        public static final int TextAppearance_Compat_Notification_Time = 0x7f12016d;
        public static final int TextAppearance_Compat_Notification_Title = 0x7f12016f;
        public static final int Widget_Compat_NotificationActionContainer = 0x7f120262;
        public static final int Widget_Compat_NotificationActionText = 0x7f120263;

        private style() {
        }
    }

    public static final class styleable {
        public static final int ColorStateListItem_alpha = 0x00000002;
        public static final int ColorStateListItem_android_alpha = 0x00000001;
        public static final int ColorStateListItem_android_color = 0x00000000;
        public static final int FontFamilyFont_android_font = 0x00000000;
        public static final int FontFamilyFont_android_fontStyle = 0x00000002;
        public static final int FontFamilyFont_android_fontVariationSettings = 0x00000004;
        public static final int FontFamilyFont_android_fontWeight = 0x00000001;
        public static final int FontFamilyFont_android_ttcIndex = 0x00000003;
        public static final int FontFamilyFont_font = 0x00000005;
        public static final int FontFamilyFont_fontStyle = 0x00000006;
        public static final int FontFamilyFont_fontVariationSettings = 0x00000007;
        public static final int FontFamilyFont_fontWeight = 0x00000008;
        public static final int FontFamilyFont_ttcIndex = 0x00000009;
        public static final int FontFamily_fontProviderAuthority = 0x00000000;
        public static final int FontFamily_fontProviderCerts = 0x00000001;
        public static final int FontFamily_fontProviderFetchStrategy = 0x00000002;
        public static final int FontFamily_fontProviderFetchTimeout = 0x00000003;
        public static final int FontFamily_fontProviderPackage = 0x00000004;
        public static final int FontFamily_fontProviderQuery = 0x00000005;
        public static final int FontFamily_fontProviderSystemFontFamily = 0x00000006;
        public static final int GradientColorItem_android_color = 0x00000000;
        public static final int GradientColorItem_android_offset = 0x00000001;
        public static final int GradientColor_android_centerColor = 0x00000007;
        public static final int GradientColor_android_centerX = 0x00000003;
        public static final int GradientColor_android_centerY = 0x00000004;
        public static final int GradientColor_android_endColor = 0x00000001;
        public static final int GradientColor_android_endX = 0x0000000a;
        public static final int GradientColor_android_endY = 0x0000000b;
        public static final int GradientColor_android_gradientRadius = 0x00000005;
        public static final int GradientColor_android_startColor = 0x00000000;
        public static final int GradientColor_android_startX = 0x00000008;
        public static final int GradientColor_android_startY = 0x00000009;
        public static final int GradientColor_android_tileMode = 0x00000006;
        public static final int GradientColor_android_type = 0x00000002;
        public static final int[] ColorStateListItem = {android.R.attr.color, android.R.attr.alpha, com.pxn.driving.R.attr.alpha};
        public static final int[] FontFamily = {com.pxn.driving.R.attr.fontProviderAuthority, com.pxn.driving.R.attr.fontProviderCerts, com.pxn.driving.R.attr.fontProviderFetchStrategy, com.pxn.driving.R.attr.fontProviderFetchTimeout, com.pxn.driving.R.attr.fontProviderPackage, com.pxn.driving.R.attr.fontProviderQuery, com.pxn.driving.R.attr.fontProviderSystemFontFamily};
        public static final int[] FontFamilyFont = {android.R.attr.font, android.R.attr.fontWeight, android.R.attr.fontStyle, android.R.attr.ttcIndex, android.R.attr.fontVariationSettings, com.pxn.driving.R.attr.font, com.pxn.driving.R.attr.fontStyle, com.pxn.driving.R.attr.fontVariationSettings, com.pxn.driving.R.attr.fontWeight, com.pxn.driving.R.attr.ttcIndex};
        public static final int[] GradientColor = {android.R.attr.startColor, android.R.attr.endColor, android.R.attr.type, android.R.attr.centerX, android.R.attr.centerY, android.R.attr.gradientRadius, android.R.attr.tileMode, android.R.attr.centerColor, android.R.attr.startX, android.R.attr.startY, android.R.attr.endX, android.R.attr.endY};
        public static final int[] GradientColorItem = {android.R.attr.color, android.R.attr.offset};

        private styleable() {
        }
    }

    private R() {
    }
}
